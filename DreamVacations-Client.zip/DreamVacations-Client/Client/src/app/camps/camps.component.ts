import { Camp } from './../shared/camp.model';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { CampService } from '../shared/camp.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-camps',
  templateUrl: './camps.component.html',
  styleUrls: ['./camps.component.css'],
  

})
export class CampsComponent implements OnInit {
  checkin:string;
  checkout:string;
  capacity:number;
  filteredCamps:Camp[]
  p:number=1;
  
  
  constructor(public service:CampService ,private router: Router){
    this.checkin = this.getDate(new Date(new Date().getTime()))    
    this.checkout = this.getDate(new Date(new Date().getTime() + 24 * 60 * 60 * 1000));
    this.capacity = 0;
    }

  ngOnInit(): void {
    this.resetForm();
     
  }
  getDate(d) {
    var output = d.getFullYear() + '-' +
        ((d.getMonth()+1)<10 ? '0' : '') + (d.getMonth()+1) + '-' +
        (d.getDate()<10 ? '0' : '') + d.getDate();
    return output ;
  }
  
  resetForm(form?:NgForm){
    if(form!=null)
    form.reset;
  
  }
  
  onSubmit(){
    this.filterCamps();
  }
  filterCamps(){
    console.log(this.checkin);
    this.service.searchCamps(this.checkin,this.checkout,this.capacity).subscribe(res=>
      this.filteredCamps= res as Camp[])
    }
  
    getBookingDetails(campId:any){
  
      this.router.navigate(['/confirmBooking',campId,this.checkin,this.checkout,this.capacity]);
      
    }

    
  }
 

  


;