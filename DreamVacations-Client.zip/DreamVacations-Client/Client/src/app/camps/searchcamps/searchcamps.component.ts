import { Component, OnInit } from '@angular/core';
import { CampService } from 'src/app/shared/camp.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-searchcamps',
  templateUrl: './searchcamps.component.html',
  styleUrls: ['./searchcamps.component.css']
})
export class SearchcampsComponent implements OnInit {

  constructor(public service:CampService) { }

  ngOnInit(): void {
    this.resetForm();
  }
  resetForm(form?:NgForm){
    if(form!=null)
    form.resetForm();
    this.service.formData={
      Id:null,
      Title:'',
      Description:'',
      Capacity:2,
      Amount:0
    }
  
  }

  onSubmit(form:NgForm){
      this.insertRecord(form);
  }
  insertRecord(form:NgForm){
    this.service.postCamp(form.value).subscribe(res=>{
      this.resetForm(form);
    });
  }
}
