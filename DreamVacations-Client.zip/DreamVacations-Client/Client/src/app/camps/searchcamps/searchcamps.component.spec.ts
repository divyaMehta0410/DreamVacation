import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchcampsComponent } from './searchcamps.component';

describe('SearchcampsComponent', () => {
  let component: SearchcampsComponent;
  let fixture: ComponentFixture<SearchcampsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchcampsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchcampsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
