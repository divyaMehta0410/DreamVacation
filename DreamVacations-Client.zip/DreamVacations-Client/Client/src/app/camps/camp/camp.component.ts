import { Camp } from './../../shared/camp.model';
import { ToastrService } from 'ngx-toastr';

import { Component, OnInit } from '@angular/core';
import { CampService } from 'src/app/shared/camp.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-camp',
  templateUrl: './camp.component.html',

})
export class CampComponent implements OnInit {
formData:Camp
  constructor(public service:CampService,private toastr:ToastrService) { 

  }

  ngOnInit(): void {
    this.resetForm(this.formData);
    this.formData=new Camp();
  }
  resetForm(formData){
    if(formData!=null)
    formData=null;
    
  
  }

  onSubmit(){
      this.insertRecord();
  }
  insertRecord(){
    this.service.postCamp(this.formData).subscribe(res=>{
      this.toastr.success("Added Successfully!","Camp.Add");
      this.resetForm(this.formData);
      
    });
  }

}
