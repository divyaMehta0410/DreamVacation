import { Booking } from './../../shared/booking.model';
import { NgForm } from '@angular/forms';
import { BookingService } from './../../shared/booking.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-manage-booking',
  templateUrl: './manage-booking.component.html',
  styleUrls: ['./manage-booking.component.css']
})
export class ManageBookingComponent implements OnInit {
referenceNumber:string
bookingDetails:Booking
  constructor(public service:BookingService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.resetForm();
    this.referenceNumber = '';
      }
  resetForm(form?:NgForm){
    if(form!=null)
    form.resetForm();
    this.service.formData={
      ReferenceNumber:null,
      CheckInDate:null,
      CheckOutDate:null,
      BillingAddress:'',
      BillingAmount:null,
      CampId:null,
      Country:'',
      State:'',
      Contact:null,
      TotalNights:0,
      ZipCode:null,
      NoOfPeople:0
    }
  }
  onSubmit(){
    this.service.getBookingDetails(this.referenceNumber).subscribe(res=>{
    this.bookingDetails=res as Booking
    })
    if(this.service.error!==undefined)
    {
      document.getElementById('error').innerHTML='No Bookings Found with Given ReferenceNumber';
    }
  }
  cancelBooking(){
    this.service.deleteBooking(this.referenceNumber).subscribe(res=>{
      if (res==true)
      {
        this.referenceNumber=null;
        this.toastr.success('Your Booking has been Cancelled'); 
      }
      else
      {
        this.toastr.show(" Plase Try Again!")
      }
    },
    error=>{
      this.toastr.show("Bookings with Past dates cant be deleted")
    }

    );
    
  }

    
}
