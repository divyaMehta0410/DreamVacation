import { NgForm } from '@angular/forms';
import { Booking } from './../../shared/booking.model';
import { Guid } from 'guid-typescript';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { BookingService } from './../../shared/booking.service';
import { Component, OnInit } from '@angular/core';
import { CampService } from 'src/app/shared/camp.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Camp } from 'src/app/shared/camp.model';

@Component({
  selector: 'app-confirmbooking',
  templateUrl: './confirmbooking.component.html',
  styleUrls: ['./confirmbooking.component.css']
})
export class ConfirmbookingComponent implements OnInit {
  campId:any
  checkIn:any
  checkOut:any
  capacity:any
  formData:Booking
  selectedCamp:Camp
  constructor(public service:CampService,public bookingService:BookingService,private activatedRouter:ActivatedRoute,private router:Router) {
    
    
       }

       ngOnInit(form?:NgForm): void {
        this.campId=this.activatedRouter.snapshot.paramMap.get('id');
        this.getCamp(this.campId);
        this.formData= new Booking();
        this.checkIn=this.activatedRouter.snapshot.paramMap.get('checkin');
        this.checkOut=this.activatedRouter.snapshot.paramMap.get('checkout');
        this.capacity=this.activatedRouter.snapshot.paramMap.get('capacity');
        
        console.log(this.campId);
        console.log(this.checkIn);
        this.resetForm();
      }

  resetForm(form?:NgForm){
    form.reset;
  }
  getCamp(campId:Guid){
    this.service.getCamp(campId).subscribe(res=>
     this.selectedCamp= res as Camp);
   
  }
  onSubmit(){
    this.formData.CampId= this.campId;
   this.formData.CheckInDate=this.checkIn;
   this.formData.CheckOutDate=this.checkOut;
   this.formData.NoOfPeople=this.capacity;
   this.bookingService.postBooking(this.formData).subscribe(res=>{
    console.log("successfully added");
    this.router.navigate(['/confirmationScreen',res]);
   },
   error=>{
     console.log(error);
   });
   
  }
  
}
