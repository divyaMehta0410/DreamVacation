import { Guid } from "guid-typescript";
export class User {
    Id: Guid
    Username:string
    Password:string
}
