import { Camp } from './camp.model';

describe('Camp', () => {
  it('should create an instance', () => {
    expect(new Camp()).toBeTruthy();
  });
});
