import { Guid } from 'guid-typescript';
import { NodeCompatibleEventEmitter } from 'rxjs/internal/observable/fromEvent';
export class Booking {
   ReferenceNumber:string
     CheckInDate:string
    CheckOutDate:string

  TotalNights:number
     BillingAddress:string
    Contact:number
    State :string
    Country:string
     ZipCode :string
     NoOfPeople :number
    CampId :Guid
   BillingAmount:number

}
