import { Search } from './search.model';

describe('Search', () => {
  it('should create an instance', () => {
    expect(new Search()).toBeTruthy();
  });
});
