export class Search {
    checkinDate:string
    checkoutDate:string
    capacity:number
}
