import { Guid } from "guid-typescript";
export class Camp {
        Id :Guid
        Title:string
        Capacity:number
        Description:string
        Amount:number
        

}
