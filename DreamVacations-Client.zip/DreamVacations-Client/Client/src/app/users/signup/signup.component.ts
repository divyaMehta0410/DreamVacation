import { User } from './../../shared/user.model';
import { UserService } from './../../shared/user.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
user:User
  constructor(public userService:UserService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.resetForm();
  }
      resetForm(form?: NgForm) {
    if (form != null)
      form.reset();
    this.user = {
      Id:null,
      Username: '',
      Password: '',
      }

  }
  OnSubmit(form: NgForm) {
    this.userService.registerUser(form.value)
      .subscribe(
        (response) => {
          console.log('response received')
          if (response!=null) {
          this.resetForm(form);
          this.toastr.success('User registration successful');
        }
        else
        {
           this.toastr.error("Registration unsuccessful");
        }
          
          console.log(response);
         
        },
        (error)=>{

          this.toastr.error(error);
         
        
          
      });
  }

  
}
