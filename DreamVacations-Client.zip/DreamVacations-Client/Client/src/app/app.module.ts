import { NgxPaginationModule } from 'ngx-pagination';

import { UserService } from './shared/user.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {  HttpClientModule} from "@angular/common/http";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import { CampsComponent } from './camps/camps.component';
import { FormsModule} from "@angular/forms";
import { CampComponent } from './camps/camp/camp.component';
import { CampService } from './shared/camp.service';
import { UsersComponent } from './users/users.component';
import { SignupComponent } from './users/signup/signup.component';
import { LoginComponent } from './admin/login/login.component';
import { ToastrModule } from "ngx-toastr";
import { HomeComponent } from './home/home.component';
import { appRoutes } from './routes';
import { AuthGuard } from './home/auth/auth.guard';
import { BookingsComponent } from './bookings/bookings.component';
import { ManageBookingComponent } from './bookings/manage-booking/manage-booking.component';
import { SearchcampsComponent } from './camps/searchcamps/searchcamps.component';
import { ConfirmbookingComponent } from './bookings/confirmbooking/confirmbooking.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminComponent } from './admin/admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageCampsComponent } from './admin/manage-camps/manage-camps.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { ConfirmationScreenComponent } from './bookings/confirmation-screen/confirmation-screen.component';
import { EditCampComponent } from './admin/edit-camp/edit-camp.component';
@NgModule({
  declarations: [
    AppComponent,
    CampsComponent,
    CampComponent,
    UsersComponent,
    SignupComponent,
    LoginComponent,
    HomeComponent,
    BookingsComponent,
    ManageBookingComponent,
    SearchcampsComponent,
    ConfirmbookingComponent,
    AdminComponent,
    DashboardComponent,
    ManageCampsComponent,
    AdminDashboardComponent,
    ConfirmationScreenComponent,
    EditCampComponent,   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),
    //NgbModule,
    NgxPaginationModule,
    NgbModule
    
    
    
  ],
  providers: [CampService,UserService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
