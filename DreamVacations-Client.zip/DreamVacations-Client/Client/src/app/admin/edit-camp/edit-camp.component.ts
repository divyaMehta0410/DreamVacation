import { Route } from '@angular/compiler/src/core';
import { Guid } from 'guid-typescript';
import { ToastrService } from 'ngx-toastr';
import { Camp } from './../../shared/camp.model';
import { CampService } from 'src/app/shared/camp.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-camp',
  templateUrl: './edit-camp.component.html',
  styleUrls: ['./edit-camp.component.css']
})
export class EditCampComponent implements OnInit {
campId:Guid
formData:Camp
  constructor(private activatedRouter:ActivatedRoute,public service:CampService,private toastr:ToastrService,private router:Router) { 
    

  }

  ngOnInit(): void {
    this.formData = new Camp();
    this.campId=(Guid).parse(this.activatedRouter.snapshot.paramMap.get('id'));
    this.getCampDetails(this.campId);
  }
  getCampDetails(campId:Guid){
    this.service.getCamp(this.campId).subscribe(res=>{
      this.formData= res as Camp
    },
    error=>{
      console.log(error);
    });
  }
  onSubmit(formData){
    this.UpdateCamp(formData);
  }
  UpdateCamp(formData){
    
    this.service.updateCamp(formData).subscribe(res=>{
      this.toastr.success("successfully Updated");
      this.router.navigate(['/manageCamps']);
    }),
    error=>{
      this.toastr.error("Please Try Again: "+error);
      console.log(error);
    }

  }

}
