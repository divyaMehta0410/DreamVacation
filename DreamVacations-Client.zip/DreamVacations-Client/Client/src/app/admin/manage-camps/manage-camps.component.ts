import { Router } from '@angular/router';
import { CampService } from 'src/app/shared/camp.service';
import { Component, OnInit } from '@angular/core';
import { Camp } from 'src/app/shared/camp.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-manage-camps',
  templateUrl: './manage-camps.component.html',
  styleUrls: ['./manage-camps.component.css']
})
export class ManageCampsComponent implements OnInit {
listOfCamps:Camp[];
p:number=1;
  constructor(private service:CampService, private toastr:ToastrService,private router:Router) { }

  ngOnInit(): void {
    this.getAllCamps()
  }
getAllCamps(){
  this.service.getCamps().subscribe(res=>
    this.listOfCamps=res as Camp[]
    ),
    error=>{
      console.log(error);
    }
    
}
EditCamp(campId){
console.log(campId);

this.router.navigate(['/editCamp',campId]);

}
DeleteCamp(campId){
  console.log(campId);
  this.service.deleteCamp(campId).subscribe(
    res=>{
    this.toastr.success("Deleted Successfully!","Camp.Add");
    this.getAllCamps();
  }
    ,
    error=>{
      this.toastr.error("Camp Not Deleted")
    }
    
);
}

}
