import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { CampComponent } from './camps/camp/camp.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ConfirmbookingComponent } from './bookings/confirmbooking/confirmbooking.component';
import { AuthGuard } from './home/auth/auth.guard';
import { UsersComponent } from './users/users.component';
import { Routes } from '@angular/router'
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './users/signup/signup.component';
import { LoginComponent } from './admin/login/login.component';
import { ManageBookingComponent } from './bookings/manage-booking/manage-booking.component';
import { AdminComponent } from './admin/admin.component';
import { ManageCampsComponent } from './admin/manage-camps/manage-camps.component';
import { ConfirmationScreenComponent } from './bookings/confirmation-screen/confirmation-screen.component';
import { EditCampComponent } from './admin/edit-camp/edit-camp.component';


export const appRoutes: Routes = [
    { path: 'home', component: HomeComponent},
    {   path:'confirmationScreen/:referenceNumber',
        component:HomeComponent,
        children:[{path:'',component:ConfirmationScreenComponent}]
    },
    {
        path:'dashboard',component:HomeComponent,
        children:[{path:'',component:DashboardComponent}]},
    {
        path:'admin', component : AdminComponent,
     
    },
    
    {path:'confirmBooking/:id/:checkin/:checkout/:capacity', component :ConfirmbookingComponent},
    //children:[{path:'',component:ConfirmbookingComponent}]},
    
    {
        path:'managebookings',component :HomeComponent,
        children:[{path:'',component:ManageBookingComponent}]
        //component:ManageBookingComponent,canActivate:[AuthGuard],
       
    },
    {
        path:'editCamp/:id',component:AdminComponent,
        children:[{path:'',component:EditCampComponent}]
    },
    {
        path:'adminDashboard',component:AdminComponent,
        children:[{path:'',component:AdminDashboardComponent}]
    },
    {
        path:'addCamp',component :AdminComponent,
        children:[{path:'',component:CampComponent,canActivate:[AuthGuard]}]
        //component:ManageBookingComponent,canActivate:[AuthGuard],
       
    },
    {
        path: 'manageCamps', component: AdminComponent,
        children: [{ path: '', component: ManageCampsComponent ,canActivate:[AuthGuard]}]
    },
    {
        path: 'login', component: HomeComponent,
        children: [
            {
            path:'',component:LoginComponent,
       
    }]
},

    { path : '', redirectTo:'dashboard', pathMatch : 'full'}
    
];
